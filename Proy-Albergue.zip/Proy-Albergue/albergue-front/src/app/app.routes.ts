import { Routes } from '@angular/router';

// Componentes Base
import { LoginComponent } from './components/login/login.component';
import { LayoutComponent } from './components/layout/layout.component';

// Componentes del Sistema (TUYOS + FUSIONADOS)
import { HabitacionListComponent } from './components/habitacion-list/habitacion-list.component';
import { RegistroListComponent } from './components/registro-list/registro-list.component';
import { RegistroComponent } from './components/registro-form/registro-form.component';
import { PersonaListComponent } from './components/persona-list/persona-list.component';
import { PersonaFormComponent } from './components/persona-form/persona-form.component';
import { UsuarioListComponent } from './components/usuario-list/usuario-list.component';

// Reportes
import { ReporteTotalComponent } from './components/reportes/reporte-total.component';
import { ReportePacientesComponent } from './components/reportes/reporte-pacientes.component';
import { ReporteEstudiantesComponent } from './components/reportes/reporte-estudiantes.component';

// Guards (YA NO LOS IMPORTAMOS O NO LOS USAMOS)
// import { AuthGuard } from './guards/auth.guard';
// import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [

  // Mantenemos la ruta de login por si acaso, pero ya no es obligatoria
  { path: 'login', component: LoginComponent },

  {
    path: '',
    component: LayoutComponent,
    // canActivate: [AuthGuard],  <-- COMENTADO: Quitamos el candado general
    children: [
      
      // === TUS RUTAS ===
      { path: 'habitaciones', component: HabitacionListComponent },
      { path: 'registros', component: RegistroListComponent },
      { path: 'registro/nuevo', component: RegistroComponent },
      { path: 'personas', component: PersonaListComponent },
      { path: 'personas/nuevo', component: PersonaFormComponent },
      { path: 'personas/editar/:id', component: PersonaFormComponent },

      // === RUTAS DEL COMPAÑERO ===
      
      // Usuarios (Le quité el AdminGuard para que puedas entrar y probar si quieres)
      {
        path: 'usuarios',
        component: UsuarioListComponent
        // canActivate: [AdminGuard] <-- COMENTADO
      },

      // Reportes
      { path: 'reportes/total', component: ReporteTotalComponent },
      { path: 'reportes/pacientes', component: ReportePacientesComponent },
      { path: 'reportes/estudiantes', component: ReporteEstudiantesComponent },

      // Redirección por defecto a HABITACIONES (No a Login)
      { path: '', redirectTo: 'habitaciones', pathMatch: 'full' }
    ]
  },

  // Si la ruta no existe, manda a habitaciones
  { path: '**', redirectTo: 'habitaciones' }
];