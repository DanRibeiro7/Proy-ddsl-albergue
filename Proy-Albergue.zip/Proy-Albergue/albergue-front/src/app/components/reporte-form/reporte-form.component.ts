import { Component } from '@angular/core';

@Component({
  selector: 'app-reporte-form',
  imports: [],
  templateUrl: './reporte-form.component.html',
  styleUrl: './reporte-form.component.css'
})
export class ReporteFormComponent {

}
